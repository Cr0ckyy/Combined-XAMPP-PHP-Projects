<?php
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Story Teller: Our Stories</title>
        <link href="stylesheets/style.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <?php
        include("navbar.php");
        ?>

    </body>
</html>