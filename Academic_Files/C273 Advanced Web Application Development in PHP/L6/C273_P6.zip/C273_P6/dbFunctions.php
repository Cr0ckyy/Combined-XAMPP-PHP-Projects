<?php
$db_host = "localhost";
$db_user = "root"; 
$db_pass = ""; 
$db_name = "c273_p06";

$link = mysqli_connect($db_host,$db_user,$db_pass,$db_name) or 
        die(mysqli_connect_error());

?>

